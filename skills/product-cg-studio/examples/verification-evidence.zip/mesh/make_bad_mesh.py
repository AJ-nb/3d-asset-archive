import sys
import bpy
from pathlib import Path

scene = bpy.context.scene
scene.unit_settings.system = "METRIC"
scene.unit_settings.scale_length = 0.001
cube = bpy.data.objects["Cube"]
cube.name = "Inverted"
cube.data.flip_normals()
points = [(0,0,0), (1,0,0), (0,1,0)]
mesh = bpy.data.meshes.new("sheet")
mesh.from_pydata(points, [], [(0,1,2)])
scene.collection.objects.link(bpy.data.objects.new("OpenSheet", mesh))
cross = bpy.data.meshes.new("cross")
cross.from_pydata([(-1,-1,0),(1,-1,0),(0,1,0),(0,-0.5,-1),(0,0.5,1),(0,0.5,-1)], [], [(0,1,2),(3,4,5)])
scene.collection.objects.link(bpy.data.objects.new("Cross", cross))
bpy.ops.wm.save_as_mainfile(filepath=str(Path(sys.argv[-1]).resolve()))
